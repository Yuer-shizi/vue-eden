<template>
  <div>
    qign page
  </div>
</template>

<script>
export default {
  name: 'attendance'
}
</script>

<style lang="stylus" scoped>

</style>
